const menu = document.querySelector('.Tipos_De_Helados');
const navegacion = document.querySelector('.navegacion');
const imagenes = document.querySelectorAll('img');
const btnTodos = document.querySelector('.todos');
const btnConos = document.querySelector('.conitos');
const btnPaletas = document.querySelector('.paletitas');
const btnVasitos = document.querySelector('.vasititos');
const btnGalletas = document.querySelector('.galletitas');
const btnCaseros = document.querySelector('.caseritos');
const contenedorPlatillos = document.querySelector('.platillos');
document.addEventListener('DOMContentLoaded',()=>{
    eventos();
    platillos();
});

const eventos = () =>{
    menu.addEventListener('click',abrirMenu);
}

const abrirMenu = () =>{
     navegacion.classList.remove('ocultar');
     botonCerrar();
}

const botonCerrar = () =>{
    const btnCerrar = document.createElement('p');
    const overlay  = document.createElement('div');
    overlay.classList.add('pantalla-completa');
    const body = document.querySelector('body');
    if(document.querySelectorAll('.pantalla-completa').length > 0) return;
    body.appendChild(overlay);
    btnCerrar.textContent = 'x';
    btnCerrar.classList.add('btn-cerrar');

    // while(navegacion.children[5]){
    //     navegacion.removeChild(navegacion.children[5]);
    // }
    navegacion.appendChild(btnCerrar);   
    cerrarMenu(btnCerrar,overlay);
    
}

const observer = new IntersectionObserver((entries, observer)=>{
        entries.forEach(entry=>{
            if(entry.isIntersecting){
                const imagen = entry.target;
                imagen.src = imagen.dataset.src;
                observer.unobserve(imagen);
            }
        }); 
});


imagenes.forEach(imagen=>{
   
    observer.observe(imagen);
});

const cerrarMenu = (boton, overlay) =>{
    boton.addEventListener('click',()=>{
        navegacion.classList.add('ocultar');
        overlay.remove();
        boton.remove();
    });

    overlay.onclick = function(){
        overlay.remove();
        navegacion.classList.add('ocultar');  
        boton.remove();
    }
}

const platillos = () =>{
    let platillosArreglo = [];
    const platillos = document.querySelectorAll('.platillo');

    platillos.forEach(platillo=> platillosArreglo = [...platillosArreglo,platillo]);

    const conitos = platillosArreglo.filter(cono=> cono.getAttribute('data-helado') === 'cono');
    const paletitas = platillosArreglo.filter(paleta => paleta.getAttribute('data-helado') === 'paleta');
    const vasititos = platillosArreglo.filter(vasito => vasito.getAttribute('data-helado') === 'vasito');
    const galletitas = platillosArreglo.filter(galleta=> galleta.getAttribute('data-helado') === 'galleta');
    const caseritos = platillosArreglo.filter(casero=> casero.getAttribute('data-helado') === 'casero');

    mostrarPlatillos(conitos, paletitas, vasititos, galletitas, caseritos, platillosArreglo);

}

const mostrarPlatillos = (conitos, paletitas, vasititos, galletitas,caseritos, todos) =>{
    btnConos.addEventListener('click', ()=>{
        limpiarHtml(contenedorPlatillos);
        conitos.forEach(cono=> contenedorPlatillos.appendChild(cono));
    });

    btnPaletas.addEventListener('click', ()=>{
        limpiarHtml(contenedorPlatillos);
         paletitas.forEach(paleta=> contenedorPlatillos.appendChild(paleta));
    });

    btnVasitos.addEventListener('click', ()=>{
        limpiarHtml(contenedorPlatillos);
        vasititos.forEach(vasito=> contenedorPlatillos.appendChild(vasito));
    });
    btnGalletas.addEventListener('click', ()=>{
        limpiarHtml(contenedorPlatillos);
        galletitas.forEach(galleta=> contenedorPlatillos.appendChild(galleta));
    });
    btnCaseros.addEventListener('click', ()=>{
        limpiarHtml(contenedorPlatillos);
        caseritos.forEach(casero=> contenedorPlatillos.appendChild(casero));
    });
    btnTodos.addEventListener('click',()=>{
        limpiarHtml(contenedorPlatillos);
        todos.forEach(todo=> contenedorPlatillos.appendChild(todo));
    });
}

const limpiarHtml = (contenedor) =>{
    while(contenedor.firstChild){
        contenedor.removeChild(contenedor.firstChild);
    }
}